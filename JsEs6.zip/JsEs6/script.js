import { getMessages, url } from './api.js'

window.addEventListener('DOMContentLoaded', async () => {

    Swal.fire(
        'Good job!',
        'You clicked the button!',
        'success'
    )

    getMessages()

    let messages = [
        {
            id: 1,
            nickname: "emir",
            message: "hello"
        },
        {
            id: 2,
            nickname: "server",
            message: "world"
        }
    ]

    // console.log(messages[0].message)

    let [ firstMessage, secondMessage ] = messages
    // let firstMessage = messages[0]
    // let secondMessage = messages[1]

    // messages.push({
    //     id: 3,
    //     message: "!"
    // })

    // let nmessage = [...messages, {  
    //     id: 3,
    //     message: "!"
    // }]

    let { id, nickname } = firstMessage
    console.log(id, nickname)
    
    // messages.forEach(({ id, nickname }, index) => {
    //     console.log(id)
    // })

    /*
    let res = await fetch('https://api.edu.etherial.dev/apijsv1/messages')
    let json = await res.json()

    console.log(json)

    let messages = json.data

    let messagesByEmir = messages.filter((message, index) => {
        if (message.nickname == "emir") {
            return true
        } else {
            return false
        }
    })

    // messages.filter((message, index) => message.nickname == "emir")

    let messageNumero400 = messages.find((message, index) => {
        if (message.id == 400) {
            return true
        }
    })

    console.log(messageNumero400)
    */

    /*
    fetch('https://api.edu.etherial.dev/apijsv1/messages').then((res) => {

        res.json().then((json) => {
            // console.log(json.data)

            let messages = json.data

            let messagesByEmir = messages.filter((message, index) => {
                if (message.nickname == "emir") {
                    return true
                } else {
                    return false
                }
            })

            // messages.filter((message, index) => message.nickname == "emir")

            let messageNumero400 = messages.find((message, index) => {
                if (message.id == 400) {
                    return true
                }
            })

            console.log(messageNumero400)

        })

    })
    */
    
    let students = [
        "Alexandre",
        "Jonathan",
        "Chabane",
        "Luis",
        "Mika",
        "Pierre",
        "William.Q",
        "Romain",
        "Ryan",
        "Rémi",
        "William.A"
    ]


    let array = students.filter((student, index) => {

        if (student == "Mika") {
            return false
        } else {
            return true
        }

    })

    //Map permet de manipuler un array en le modifiant

    let array2 = array.map((student, index) => {  
        return student.substring(0, 1)
    })

    // console.log(array2)

    


})

// window.addEventListener('DOMContentLoaded', function () {
    
// })