export function getMessages() {

    fetch('https://api.edu.etherial.dev/apijsv1/messages').then((res) => {

        res.json().then((json) => {
            // console.log(json.data)

            let messages = json.data

            let messagesByEmir = messages.filter((message, index) => {
                if (message.nickname == "emir") {
                    return true
                } else {
                    return false
                }
            })

            // messages.filter((message, index) => message.nickname == "emir")

            let messageNumero400 = messages.find((message, index) => {
                if (message.id == 400) {
                    return true
                }
            })

            console.log(messageNumero400)

        })

    })

}

export let url = "https://api.edu.etherial.dev"